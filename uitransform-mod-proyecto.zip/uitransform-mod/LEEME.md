# Ultra Instinct Transformation (mod de Fabric para Minecraft 1.21.11)

Mod solo de cliente. Pulsas una tecla y:

1. Un aura azul-blanca crece alrededor de tu cuerpo hasta cubrirte de blanco brillante (emisivo: brilla aunque estes en una cueva oscura). Te puedes mover con total libertad. Se ve en primera y en tercera persona.
2. El blanco estalla en cientos de particulas emisivas que salen volando y aparece la skin que elegiste.
3. Pulsa la tecla otra vez para volver a tu skin normal.

## Teclas

- **U** = transformarse / volver a normal
- **I** = abrir la configuracion de skins
- Tambien hay un boton **"Ultra Instinto: skins"** arriba a la izquierda en el menu principal y en el de pausa (comodo en el celular).
- Las dos teclas se cambian en Opciones > Controles > "Ultra Instinct Transformation".

## Anadir skins

En la configuracion pulsa **"Anadir skin (gestor de archivos)"**:

- **PC (Windows / Mac / Linux):** se abre el selector de archivos de tu sistema; eliges el PNG y listo. Tambien puedes arrastrar el PNG encima de la ventana del juego.
- **Android:** se abre el gestor de archivos del telefono en la carpeta de skins. Copia ahi tu PNG y pulsa "Actualizar lista".
- Si el gestor de archivos no se abre, usa **"Explorador del juego"**: es un explorador dentro de Minecraft (empieza en Descargas) y funciona igual en cualquier dispositivo.

La skin tiene que ser un PNG de 64x64 (o 64x32). Se guardan en `config/uitransform/skins/`.
Si tus brazos salen mal, cambia "Brazos" entre Automatico / Normales / Delgados (Alex).

## Instalar

1. Fabric Loader para 1.21.11 (0.20.1 o mas nuevo)
2. Fabric API para 1.21.11
3. El .jar de este mod en la carpeta `mods`

## Como convertir esto en el .jar

### Opcion A: sin PC (desde el celular, con GitHub) - usa el archivo `build.yml`

1. Entra a github.com, crea una cuenta gratis y pulsa **New repository** -> ponle cualquier nombre -> **Create repository**.
2. Dentro del repositorio pulsa **Add file -> Create new file**.
3. En el nombre escribe exactamente `.github/workflows/build.yml` (al escribir `/` se crean las carpetas).
4. Pega TODO el contenido del archivo `build.yml` que te di y pulsa **Commit changes**.
5. Ve a la pestana **Actions**. Se ejecuta solo (si no, entra a "build-mod" -> **Run workflow**). Tarda unos 3-5 minutos.
6. Abre la ejecucion terminada, baja hasta **Artifacts** y descarga **uitransform-mod**. Dentro del zip esta `uitransform-1.0.0.jar`.
7. Pon ese .jar en la carpeta `mods`.

### Opcion B: en PC

Descomprime este zip y ejecuta `./gradlew build` (Windows: `gradlew.bat build`) con Java 21 o mas nuevo. El mod queda en `build/libs/uitransform-1.0.0.jar` (no uses el que dice `-sources`).

## Si falla al compilar o al abrir el juego

Copia el error (Actions -> el paso en rojo, o `logs/latest.log` del juego) y mandamelo; lo corrijo.
