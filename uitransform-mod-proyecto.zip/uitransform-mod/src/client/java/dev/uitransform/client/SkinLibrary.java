package dev.uitransform.client;

import com.mojang.blaze3d.platform.NativeImage;
import dev.uitransform.UiTransformMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.core.ClientAsset;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Maneja la carpeta de skins, las importa y las convierte en texturas del juego.
 * Todo lo que toca texturas debe llamarse desde el hilo principal del juego.
 */
public final class SkinLibrary {
	private SkinLibrary() {
	}

	/** Textura blanca solida (el "caparazon" de luz). Tambien la usa la capa de brillo. */
	public static final Identifier WHITE_TEXTURE = Identifier.fromNamespaceAndPath(UiTransformMod.MOD_ID, "textures/dynamic/white.png");
	private static final Identifier WHITE_ID = Identifier.fromNamespaceAndPath(UiTransformMod.MOD_ID, "white");
	private static final Identifier CUSTOM_TEXTURE = Identifier.fromNamespaceAndPath(UiTransformMod.MOD_ID, "textures/dynamic/custom_skin.png");
	private static final Identifier CUSTOM_ID = Identifier.fromNamespaceAndPath(UiTransformMod.MOD_ID, "custom_skin");

	private static PlayerSkin.Patch whitePatch;
	private static PlayerSkin.Patch customPatch;
	private static boolean dirty = true;

	public record ImportResult(String name, Component error) {
		static ImportResult ok(String name) {
			return new ImportResult(name, null);
		}

		static ImportResult error(Component error) {
			return new ImportResult(null, error);
		}
	}

	public static Path skinsDir() {
		return UiConfig.skinsDirectory();
	}

	/** Nombres de los .png que hay en la carpeta de skins. */
	public static List<String> list() {
		Path dir = skinsDir();
		List<String> names = new ArrayList<>();

		try {
			Files.createDirectories(dir);

			try (Stream<Path> stream = Files.list(dir)) {
				stream.filter(Files::isRegularFile)
						.map(p -> p.getFileName().toString())
						.filter(n -> n.toLowerCase(Locale.ROOT).endsWith(".png"))
						.forEach(names::add);
			}
		} catch (IOException e) {
			UiTransformMod.LOGGER.warn("No se pudo listar la carpeta de skins", e);
		}

		names.sort(String.CASE_INSENSITIVE_ORDER);
		return names;
	}

	/** Marca que hay que volver a cargar la skin elegida (cambio de skin o de tipo de brazos). */
	public static void invalidate() {
		dirty = true;
	}

	/** Copia un PNG a la carpeta de skins (comprobando que sea una skin valida). */
	public static ImportResult importSkin(Path source) {
		try {
			if (!Files.isRegularFile(source)) {
				return ImportResult.error(Component.translatable("uitransform.status.not_file"));
			}

			String fileName = source.getFileName().toString();

			if (!fileName.toLowerCase(Locale.ROOT).endsWith(".png")) {
				return ImportResult.error(Component.translatable("uitransform.status.not_png"));
			}

			try (InputStream in = Files.newInputStream(source); NativeImage image = NativeImage.read(in)) {
				if (image.getWidth() != 64 || (image.getHeight() != 64 && image.getHeight() != 32)) {
					return ImportResult.error(Component.translatable("uitransform.status.bad_size", image.getWidth(), image.getHeight()));
				}
			}

			Path dir = skinsDir();
			Files.createDirectories(dir);

			Path normalizedSource = source.toAbsolutePath().normalize();

			if (normalizedSource.getParent() != null && normalizedSource.getParent().equals(dir.toAbsolutePath().normalize())) {
				return ImportResult.ok(fileName); // ya estaba en la carpeta
			}

			String base = sanitize(fileName.substring(0, fileName.length() - 4));
			String name = base + ".png";
			int counter = 2;

			while (Files.exists(dir.resolve(name))) {
				name = base + "_" + counter++ + ".png";
			}

			Files.copy(source, dir.resolve(name));
			return ImportResult.ok(name);
		} catch (Exception e) {
			UiTransformMod.LOGGER.warn("No se pudo importar la skin", e);
			return ImportResult.error(Component.translatable("uitransform.status.import_failed"));
		}
	}

	private static String sanitize(String name) {
		String clean = name.replaceAll("[^A-Za-z0-9._-]", "_");
		return clean.isEmpty() ? "skin" : clean;
	}

	// ------------------------------------------------------------------ texturas

	/** Registra la textura blanca y (si hace falta) vuelve a cargar la skin elegida. True si hay skin lista. */
	public static boolean ensureReady() {
		ensureWhite();

		if (dirty) {
			dirty = false;
			loadCustom();
		}

		return customPatch != null;
	}

	/** Parche de skin totalmente blanco (para el caparazon de luz). */
	public static PlayerSkin.Patch whitePatch() {
		return whitePatch;
	}

	/** Parche con la skin que elegiste en la configuracion, o null si no hay ninguna valida. */
	public static PlayerSkin.Patch customPatch() {
		return customPatch;
	}

	private static void ensureWhite() {
		if (whitePatch != null) {
			return;
		}

		try {
			NativeImage white = new NativeImage(64, 64, false);

			for (int y = 0; y < 64; y++) {
				for (int x = 0; x < 64; x++) {
					white.setPixel(x, y, 0xFFFFFFFF);
				}
			}

			DynamicTexture texture = new DynamicTexture(() -> "uitransform white", white);
			texture.upload();
			textures().register(WHITE_TEXTURE, texture);

			whitePatch = new PlayerSkin.Patch(
					Optional.of(new ClientAsset.ResourceTexture(WHITE_ID, WHITE_TEXTURE)),
					Optional.empty(),
					Optional.empty(),
					Optional.empty());
		} catch (Exception e) {
			UiTransformMod.LOGGER.error("No se pudo crear la textura blanca", e);
		}
	}

	private static void loadCustom() {
		customPatch = null;
		String name = UiConfig.get().selectedSkin;

		if (name == null || name.isEmpty()) {
			return;
		}

		Path file = skinsDir().resolve(name);

		if (!Files.isRegularFile(file)) {
			return;
		}

		try {
			NativeImage image = readAsModernSkin(file);
			boolean slim = UiConfig.get().arms == UiConfig.Arms.SLIM
					|| (UiConfig.get().arms == UiConfig.Arms.AUTO && detectSlim(image));

			fixBaseAlpha(image);

			DynamicTexture texture = new DynamicTexture(() -> "uitransform skin " + name, image);
			texture.upload();
			textures().register(CUSTOM_TEXTURE, texture);

			customPatch = new PlayerSkin.Patch(
					Optional.of(new ClientAsset.ResourceTexture(CUSTOM_ID, CUSTOM_TEXTURE)),
					Optional.empty(),
					Optional.empty(),
					Optional.of(slim ? PlayerModelType.SLIM : PlayerModelType.WIDE));
		} catch (Exception e) {
			UiTransformMod.LOGGER.warn("No se pudo cargar la skin {}", name, e);
		}
	}

	private static TextureManager textures() {
		return Minecraft.getInstance().getTextureManager();
	}

	/** Lee el PNG; si es una skin antigua 64x32 la convierte al formato 64x64 de hoy. */
	private static NativeImage readAsModernSkin(Path file) throws IOException {
		NativeImage raw;

		try (InputStream in = Files.newInputStream(file)) {
			raw = NativeImage.read(in);
		}

		if (raw.getWidth() != 64 || (raw.getHeight() != 64 && raw.getHeight() != 32)) {
			int w = raw.getWidth();
			int h = raw.getHeight();
			raw.close();
			throw new IOException("Tamano de skin no valido: " + w + "x" + h);
		}

		if (raw.getHeight() == 64) {
			return raw;
		}

		NativeImage image = new NativeImage(64, 64, true);

		for (int y = 0; y < 32; y++) {
			for (int x = 0; x < 64; x++) {
				image.setPixel(x, y, raw.getPixel(x, y));
			}
		}

		raw.close();

		// Pierna y brazo izquierdos = espejo de los derechos (igual que hace Minecraft con skins viejas).
		mirrorCopy(image, 4, 16, 16, 32, 4, 4);
		mirrorCopy(image, 8, 16, 16, 32, 4, 4);
		mirrorCopy(image, 0, 20, 24, 32, 4, 12);
		mirrorCopy(image, 4, 20, 16, 32, 4, 12);
		mirrorCopy(image, 8, 20, 8, 32, 4, 12);
		mirrorCopy(image, 12, 20, 16, 32, 4, 12);
		mirrorCopy(image, 44, 16, -8, 32, 4, 4);
		mirrorCopy(image, 48, 16, -8, 32, 4, 4);
		mirrorCopy(image, 40, 20, 0, 32, 4, 12);
		mirrorCopy(image, 44, 20, -8, 32, 4, 12);
		mirrorCopy(image, 48, 20, -16, 32, 4, 12);
		mirrorCopy(image, 52, 20, -8, 32, 4, 12);
		return image;
	}

	private static void mirrorCopy(NativeImage image, int x, int y, int dx, int dy, int width, int height) {
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				image.setPixel(x + dx + (width - 1 - i), y + dy + j, image.getPixel(x + i, y + j));
			}
		}
	}

	/** Las skins de brazos delgados (Alex) dejan transparente la ultima columna del brazo derecho. */
	private static boolean detectSlim(NativeImage image) {
		for (int y = 20; y < 32; y++) {
			if (((image.getPixel(55, y) >>> 24) & 0xFF) != 0) {
				return false;
			}
		}

		return true;
	}

	/** La capa base del cuerpo tiene que ser opaca (si no, se veria "hueca"). */
	private static void fixBaseAlpha(NativeImage image) {
		opaque(image, 0, 0, 32, 16);
		opaque(image, 0, 16, 64, 32);
		opaque(image, 16, 48, 48, 64);
	}

	private static void opaque(NativeImage image, int x1, int y1, int x2, int y2) {
		for (int y = y1; y < y2; y++) {
			for (int x = x1; x < x2; x++) {
				image.setPixel(x, y, image.getPixel(x, y) | 0xFF000000);
			}
		}
	}
}
