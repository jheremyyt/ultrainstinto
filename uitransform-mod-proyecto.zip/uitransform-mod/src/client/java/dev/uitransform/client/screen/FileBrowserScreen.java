package dev.uitransform.client.screen;

import dev.uitransform.client.PlatformUtil;
import dev.uitransform.client.SkinLibrary;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.stream.Stream;

/**
 * Explorador de archivos dentro del juego. Funciona igual en Android y en PC:
 * sirve de respaldo cuando el gestor de archivos del sistema no se puede abrir.
 */
public class FileBrowserScreen extends Screen {
	private final Screen parent;
	private final Consumer<Path> onPick;
	private Path dir;
	private List<Path> entries = new ArrayList<>();
	private int page;
	private int rowsPerPage = 5;
	private int pageLabelY;
	private String error = "";
	private EditBox pathBox;

	public FileBrowserScreen(Screen parent, Consumer<Path> onPick) {
		super(Component.translatable("uitransform.browser.title"));
		this.parent = parent;
		this.onPick = onPick;
		this.dir = startDirectory();
		scan();
	}

	private static Path startDirectory() {
		if (PlatformUtil.isAndroid()) {
			for (String candidate : new String[]{"/storage/emulated/0/Download", "/storage/emulated/0", "/sdcard"}) {
				Path path = Path.of(candidate);

				if (Files.isDirectory(path)) {
					return path;
				}
			}
		}

		Path home = Path.of(System.getProperty("user.home", "."));
		Path downloads = home.resolve("Downloads");
		return Files.isDirectory(downloads) ? downloads : home;
	}

	private void scan() {
		entries = new ArrayList<>();
		error = "";

		try (Stream<Path> stream = Files.list(dir)) {
			stream.filter(path -> {
				String name = path.getFileName().toString();

				if (name.startsWith(".")) {
					return false;
				}

				return Files.isDirectory(path) || name.toLowerCase(Locale.ROOT).endsWith(".png");
			}).forEach(entries::add);
		} catch (IOException | RuntimeException e) {
			error = String.valueOf(e.getMessage());
		}

		entries.sort(Comparator
				.comparing((Path path) -> !Files.isDirectory(path))
				.thenComparing(path -> path.getFileName().toString().toLowerCase(Locale.ROOT)));
		page = 0;
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int boxWidth = Math.min(300, this.width - 20);
		int left = cx - boxWidth / 2;
		int rowGap = 22;

		pathBox = new EditBox(this.font, left, 20, boxWidth - 34, 18, Component.translatable("uitransform.browser.path"));
		pathBox.setMaxLength(1024);
		pathBox.setValue(dir.toString());
		this.addRenderableWidget(pathBox);
		this.addRenderableWidget(Button.builder(Component.translatable("uitransform.browser.go"), button -> goToText())
				.bounds(left + boxWidth - 32, 19, 32, 20).build());

		int yCancel = this.height - 28;
		int yPage = yCancel - rowGap;
		int yShortcuts = yPage - rowGap;
		pageLabelY = yPage + 6;

		int shortcutWidth = (boxWidth - 8) / 3;
		this.addRenderableWidget(Button.builder(Component.translatable("uitransform.browser.up"), button -> {
			Path parentDir = dir.getParent();

			if (parentDir != null) {
				open(parentDir);
			}
		}).bounds(left, yShortcuts, shortcutWidth, 20).build());
		this.addRenderableWidget(Button.builder(Component.translatable("uitransform.browser.downloads"), button -> {
			Path home = Path.of(System.getProperty("user.home", "."));
			Path[] candidates = {
					Path.of("/storage/emulated/0/Download"),
					home.resolve("Downloads"),
					home.resolve("Download")
			};

			for (Path candidate : candidates) {
				if (Files.isDirectory(candidate)) {
					open(candidate);
					return;
				}
			}
		}).bounds(left + shortcutWidth + 4, yShortcuts, shortcutWidth, 20).build());
		this.addRenderableWidget(Button.builder(Component.translatable("uitransform.browser.skins"), button -> open(SkinLibrary.skinsDir()))
				.bounds(left + (shortcutWidth + 4) * 2, yShortcuts, shortcutWidth, 20).build());

		int listTop = 44;
		rowsPerPage = Math.max(1, Math.min(8, (yShortcuts - 4 - listTop) / rowGap));
		int pages = Math.max(1, (entries.size() + rowsPerPage - 1) / rowsPerPage);
		page = Math.max(0, Math.min(page, pages - 1));

		for (int i = 0; i < rowsPerPage; i++) {
			int index = page * rowsPerPage + i;

			if (index >= entries.size()) {
				break;
			}

			Path entry = entries.get(index);
			boolean folder = Files.isDirectory(entry);
			String name = entry.getFileName().toString();
			Component label = Component.literal(folder ? "[ " + name + " ]" : name);

			this.addRenderableWidget(Button.builder(label, button -> {
				if (folder) {
					open(entry);
				} else {
					this.minecraft.setScreen(parent);
					onPick.accept(entry);
				}
			}).bounds(left, listTop + i * rowGap, boxWidth, 20).build());
		}

		Button previous = Button.builder(Component.literal("<"), button -> {
			page--;
			this.rebuildWidgets();
		}).bounds(cx - 70, yPage, 30, 20).build();
		previous.active = page > 0;
		this.addRenderableWidget(previous);

		Button next = Button.builder(Component.literal(">"), button -> {
			page++;
			this.rebuildWidgets();
		}).bounds(cx + 40, yPage, 30, 20).build();
		next.active = page < pages - 1;
		this.addRenderableWidget(next);

		this.addRenderableWidget(Button.builder(Component.translatable("uitransform.browser.cancel"), button -> this.onClose())
				.bounds(cx - 75, yCancel, 150, 20).build());
	}

	private void open(Path path) {
		this.dir = path;
		scan();
		this.rebuildWidgets();
	}

	private void goToText() {
		try {
			Path path = Path.of(pathBox.getValue().trim());

			if (Files.isDirectory(path)) {
				open(path);
			} else if (Files.isRegularFile(path)) {
				this.minecraft.setScreen(parent);
				onPick.accept(path);
			} else {
				error = Component.translatable("uitransform.browser.not_found").getString();
			}
		} catch (RuntimeException e) {
			error = Component.translatable("uitransform.browser.not_found").getString();
		}
	}

	@Override
	public void onClose() {
		this.minecraft.setScreen(parent);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		super.render(graphics, mouseX, mouseY, partialTick);

		graphics.drawString(this.font, this.title, (this.width - this.font.width(this.title)) / 2, 7, 0xFFFFFFFF);

		if (!error.isEmpty()) {
			graphics.drawString(this.font, error, 10, 40, 0xFFFF5555);
		} else if (entries.isEmpty()) {
			Component empty = Component.translatable("uitransform.browser.empty");
			graphics.drawString(this.font, empty, (this.width - this.font.width(empty)) / 2, 56, 0xFFC0C0C0);
		}

		int pages = Math.max(1, (entries.size() + rowsPerPage - 1) / rowsPerPage);
		Component pageLabel = Component.translatable("uitransform.screen.page", page + 1, pages);
		graphics.drawString(this.font, pageLabel, (this.width - this.font.width(pageLabel)) / 2, pageLabelY, 0xFFFFFFFF);
	}
}
