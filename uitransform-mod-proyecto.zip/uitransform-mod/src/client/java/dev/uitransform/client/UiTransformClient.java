package dev.uitransform.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.uitransform.UiTransformMod;
import dev.uitransform.client.screen.SkinConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class UiTransformClient implements ClientModInitializer {
	public static KeyMapping transformKey;
	public static KeyMapping configKey;

	@SuppressWarnings({"unchecked", "rawtypes"})
	@Override
	public void onInitializeClient() {
		UiConfig.load();

		// Las dos teclas se pueden cambiar en Opciones > Controles > "Ultra Instinct Transformation".
		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(UiTransformMod.MOD_ID, "main"));
		transformKey = KeyBindingHelper.registerKeyBinding(
				new KeyMapping("key.uitransform.transform", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_U, category));
		configKey = KeyBindingHelper.registerKeyBinding(
				new KeyMapping("key.uitransform.config", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_I, category));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (transformKey.consumeClick()) {
				UiTransformation.toggle(client);
			}

			while (configKey.consumeClick()) {
				client.setScreen(new SkinConfigScreen(null));
			}

			UiTransformation.tick(client);
		});

		// Aura emisiva sobre tu cuerpo (tercera persona).
		LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, entityRenderer, registrationHelper, context) -> {
			if (entityRenderer instanceof AvatarRenderer) {
				registrationHelper.register(new AuraLayer((RenderLayerParent<AvatarRenderState, PlayerModel>) (RenderLayerParent) entityRenderer));
			}
		});

		// Destello y bordes de luz en pantalla (primera y tercera persona).
		HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(UiTransformMod.MOD_ID, "overlay"),
				(graphics, tickCounter) -> UiTransformation.renderOverlay(graphics));

		// Boton para abrir la configuracion desde el menu principal y el de pausa
		// (util en el celular, donde es incomodo pulsar una tecla).
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			if (screen instanceof PauseScreen || screen instanceof TitleScreen) {
				Screens.getButtons(screen).add(Button.builder(Component.translatable("uitransform.button.open"),
						button -> client.setScreen(new SkinConfigScreen(screen))).bounds(6, 6, 120, 20).build());
			}
		});
	}
}
