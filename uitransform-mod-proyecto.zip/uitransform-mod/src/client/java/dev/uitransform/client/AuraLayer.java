package dev.uitransform.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;

/**
 * Capa que dibuja el aura emisiva (luz maxima, sin importar la oscuridad) sobre tu cuerpo
 * en tercera persona. En primera persona el efecto lo hacen la skin blanca, la mano brillante y la pantalla.
 */
public final class AuraLayer extends RenderLayer<AvatarRenderState, PlayerModel> {
	public AuraLayer(RenderLayerParent<AvatarRenderState, PlayerModel> parent) {
		super(parent);
	}

	@Override
	public void submit(PoseStack poseStack, SubmitNodeCollector collector, int light, AvatarRenderState state, float yRot, float xRot) {
		Minecraft mc = Minecraft.getInstance();

		if (mc.player == null || state.id != mc.player.getId()) {
			return; // solo el aura del jugador local
		}

		UiTransformation.Shell shell = UiTransformation.shell(System.currentTimeMillis());

		if (shell == null) {
			return;
		}

		RenderType type = RenderTypes.entityTranslucent(SkinLibrary.WHITE_TEXTURE);

		if (shell.coreAlpha() > 0.02f) {
			draw(poseStack, collector, state, type, 1, shell.coreScale(), UiTransformation.argb(shell.coreAlpha(), shell.coreRgb()));
		}

		if (shell.haloAlpha() > 0.02f) {
			draw(poseStack, collector, state, type, 2, shell.haloScale(), UiTransformation.argb(shell.haloAlpha(), shell.haloRgb()));
		}
	}

	private void draw(PoseStack poseStack, SubmitNodeCollector collector, AvatarRenderState state, RenderType type, int order, float scale, int tint) {
		poseStack.pushPose();
		// Se agranda alrededor del centro del cuerpo (en el modelo, y = 0.5 es la cintura).
		poseStack.translate(0.0F, 0.5F, 0.0F);
		poseStack.scale(scale, scale, scale);
		poseStack.translate(0.0F, -0.5F, 0.0F);
		collector.order(order).submitModel(this.getParentModel(), state, poseStack, type,
				LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, tint, null, 0, null);
		poseStack.popPose();
	}
}
