package dev.uitransform.client.screen;

import dev.uitransform.client.PlatformUtil;
import dev.uitransform.client.SkinLibrary;
import dev.uitransform.client.UiConfig;
import dev.uitransform.client.UiTransformation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Pantalla de configuracion: lista de skins, anadir skin (gestor de archivos), brazos y particulas. */
public class SkinConfigScreen extends Screen {
	private final Screen parent;
	private List<String> skins = new ArrayList<>();
	private int page;
	private int rowsPerPage = 4;
	private int pageLabelY;
	private Component status = Component.empty();

	public SkinConfigScreen(Screen parent) {
		super(Component.translatable("uitransform.screen.title"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		UiConfig cfg = UiConfig.get();
		skins = SkinLibrary.list();

		int cx = this.width / 2;
		int colWidth = Math.min(150, (this.width - 20) / 2 - 3);
		int left = cx - colWidth - 3;
		int right = cx + 3;
		int rowGap = 22;

		int yDone = this.height - 28;
		int yParticles = yDone - rowGap;
		int yBrowser = yParticles - rowGap;
		int yAdd = yBrowser - rowGap;
		int yPage = yAdd - rowGap;
		pageLabelY = yPage + 6;

		int listTop = 40;
		int listWidth = Math.min(300, this.width - 20);
		rowsPerPage = Math.max(1, Math.min(8, (yPage - 4 - listTop) / rowGap));
		int pages = Math.max(1, (skins.size() + rowsPerPage - 1) / rowsPerPage);
		page = Math.max(0, Math.min(page, pages - 1));

		for (int i = 0; i < rowsPerPage; i++) {
			int index = page * rowsPerPage + i;

			if (index >= skins.size()) {
				break;
			}

			String name = skins.get(index);
			boolean selected = name.equals(cfg.selectedSkin);
			Component label = Component.literal(selected ? "> " + name + " <" : name);

			this.addRenderableWidget(Button.builder(label, button -> {
				cfg.selectedSkin = name;
				UiConfig.save();
				SkinLibrary.invalidate();
				status = Component.translatable("uitransform.status.selected", name);
				this.rebuildWidgets();
			}).bounds(cx - listWidth / 2, listTop + i * rowGap, listWidth, 20).build());
		}

		Button previous = Button.builder(Component.literal("<"), button -> {
			page--;
			this.rebuildWidgets();
		}).bounds(cx - 70, yPage, 30, 20).build();
		previous.active = page > 0;
		this.addRenderableWidget(previous);

		Button next = Button.builder(Component.literal(">"), button -> {
			page++;
			this.rebuildWidgets();
		}).bounds(cx + 40, yPage, 30, 20).build();
		next.active = page < pages - 1;
		this.addRenderableWidget(next);

		// Fila 1: anadir skin con el gestor de archivos del sistema / abrir la carpeta
		this.addRenderableWidget(Button.builder(Component.translatable("uitransform.button.add"), button -> addSkinWithSystemPicker())
				.bounds(left, yAdd, colWidth, 20).build());
		this.addRenderableWidget(Button.builder(Component.translatable("uitransform.button.folder"), button -> openFolder())
				.bounds(right, yAdd, colWidth, 20).build());

		// Fila 2: explorador dentro del juego / actualizar lista
		this.addRenderableWidget(Button.builder(Component.translatable("uitransform.button.browser"),
						button -> this.minecraft.setScreen(new FileBrowserScreen(this, this::importFile)))
				.bounds(left, yBrowser, colWidth, 20).build());
		this.addRenderableWidget(Button.builder(Component.translatable("uitransform.button.refresh"), button -> {
			status = Component.translatable("uitransform.status.refreshed");
			this.rebuildWidgets();
		}).bounds(right, yBrowser, colWidth, 20).build());

		// Fila 3: tipo de brazos / cantidad de particulas
		this.addRenderableWidget(Button.builder(
						Component.translatable("uitransform.button.arms",
								Component.translatable("uitransform.arms." + cfg.arms.name().toLowerCase(Locale.ROOT))),
						button -> {
							cfg.arms = cfg.arms.next();
							UiConfig.save();
							SkinLibrary.invalidate();
							this.rebuildWidgets();
						})
				.bounds(left, yParticles, colWidth, 20).build());
		this.addRenderableWidget(Button.builder(
						Component.translatable("uitransform.button.particles",
								Component.translatable("uitransform.particles." + cfg.particles.name().toLowerCase(Locale.ROOT))),
						button -> {
							cfg.particles = cfg.particles.next();
							UiConfig.save();
							this.rebuildWidgets();
						})
				.bounds(right, yParticles, colWidth, 20).build());

		// Fila 4: probar / listo
		Button test = Button.builder(Component.translatable("uitransform.button.test"), button -> {
			Minecraft mc = this.minecraft;
			mc.setScreen(null);
			UiTransformation.toggle(mc);
		}).bounds(left, yDone, colWidth, 20).build();
		test.active = this.minecraft != null && this.minecraft.player != null;
		this.addRenderableWidget(test);

		this.addRenderableWidget(Button.builder(Component.translatable("uitransform.button.done"), button -> this.onClose())
				.bounds(right, yDone, colWidth, 20).build());
	}

	// ------------------------------------------------------------------ acciones

	/** Android: abre el gestor de archivos del telefono. PC: abre el selector de archivos del sistema. */
	private void addSkinWithSystemPicker() {
		Path dir = SkinLibrary.skinsDir();
		status = Component.translatable("uitransform.status.opening");

		Thread thread = new Thread(() -> {
			Minecraft mc = Minecraft.getInstance();

			if (PlatformUtil.isAndroid()) {
				boolean opened = PlatformUtil.openFileManager(dir);
				Component message = opened
						? Component.translatable("uitransform.status.android_opened")
						: Component.translatable("uitransform.status.android_failed", dir.toString());
				mc.execute(() -> status = message);
				return;
			}

			PlatformUtil.PickResult result = PlatformUtil.pickPng();

			if (result.path() != null) {
				mc.execute(() -> importFile(result.path()));
			} else if (result.unavailable()) {
				PlatformUtil.openFileManager(dir);
				mc.execute(() -> status = Component.translatable("uitransform.status.folder_opened", dir.toString()));
			} else {
				mc.execute(() -> status = Component.empty());
			}
		}, "uitransform-file-picker");
		thread.setDaemon(true);
		thread.start();
	}

	private void openFolder() {
		Path dir = SkinLibrary.skinsDir();
		status = Component.translatable("uitransform.status.opening");

		Thread thread = new Thread(() -> {
			boolean opened = PlatformUtil.openFileManager(dir);
			Component message = opened
					? Component.translatable("uitransform.status.folder_opened", dir.toString())
					: Component.translatable("uitransform.status.android_failed", dir.toString());
			Minecraft.getInstance().execute(() -> status = message);
		}, "uitransform-open-folder");
		thread.setDaemon(true);
		thread.start();
	}

	/** Copia el PNG a la carpeta de skins y lo deja elegido. */
	private void importFile(Path path) {
		SkinLibrary.ImportResult result = SkinLibrary.importSkin(path);

		if (result.error() != null) {
			status = result.error();
		} else {
			UiConfig cfg = UiConfig.get();
			cfg.selectedSkin = result.name();
			UiConfig.save();
			SkinLibrary.invalidate();
			status = Component.translatable("uitransform.status.added", result.name());
		}

		this.rebuildWidgets();
	}

	@Override
	public void onFilesDrop(List<Path> paths) {
		// En PC tambien puedes arrastrar el PNG encima de la ventana del juego.
		for (Path path : paths) {
			importFile(path);
			return;
		}
	}

	@Override
	public void onClose() {
		UiConfig.save();
		this.minecraft.setScreen(parent);
	}

	// -------------------------------------------------------------------- dibujo

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		super.render(graphics, mouseX, mouseY, partialTick);

		graphics.drawString(this.font, this.title, (this.width - this.font.width(this.title)) / 2, 8, 0xFFFFFFFF);

		String selected = UiConfig.get().selectedSkin;
		Component selectedLine = selected.isEmpty()
				? Component.translatable("uitransform.screen.none")
				: Component.translatable("uitransform.screen.selected", selected);
		graphics.drawString(this.font, selectedLine, (this.width - this.font.width(selectedLine)) / 2, 20, 0xFFA0E0FF);

		if (!status.getString().isEmpty()) {
			graphics.drawString(this.font, status, (this.width - this.font.width(status)) / 2, 30, 0xFFFFFF55);
		}

		if (skins.isEmpty()) {
			Component[] lines = {
					Component.translatable("uitransform.empty.1"),
					Component.translatable("uitransform.empty.2"),
					Component.translatable("uitransform.empty.3")
			};

			for (int i = 0; i < lines.length; i++) {
				graphics.drawString(this.font, lines[i], (this.width - this.font.width(lines[i])) / 2, 48 + i * 11, 0xFFC0C0C0);
			}
		}

		int pages = Math.max(1, (skins.size() + rowsPerPage - 1) / rowsPerPage);
		Component pageLabel = Component.translatable("uitransform.screen.page", page + 1, pages);
		graphics.drawString(this.font, pageLabel, (this.width - this.font.width(pageLabel)) / 2, pageLabelY, 0xFFFFFFFF);
	}
}
