package dev.uitransform.client;

import dev.uitransform.UiTransformMod;
import net.minecraft.util.Util;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Cosas que dependen del sistema: abrir el gestor de archivos (Android / Windows / Mac / Linux)
 * y elegir un PNG con el selector nativo en PC.
 * Todo esto es bloqueante: llamalo desde un hilo aparte, nunca desde el hilo del juego.
 */
public final class PlatformUtil {
	private PlatformUtil() {
	}

	/** path != null: archivo elegido. unavailable: no hay selector nativo disponible. Ambos falsos: cancelado. */
	public record PickResult(Path path, boolean unavailable) {
		static final PickResult CANCELLED = new PickResult(null, false);
		static final PickResult UNAVAILABLE = new PickResult(null, true);
	}

	private static final String OS = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);

	public static boolean isAndroid() {
		// Pojav, Zalith, FCL, etc. corren dentro de un proceso Android: estas variables siempre existen ahi.
		return System.getenv("ANDROID_ROOT") != null
				|| System.getenv("ANDROID_DATA") != null
				|| System.getenv("POJAV_RENDERER") != null
				|| Files.exists(Path.of("/system/build.prop"));
	}

	public static boolean isWindows() {
		return OS.contains("win");
	}

	public static boolean isMac() {
		return OS.contains("mac");
	}

	/** Abre el gestor de archivos del sistema en esa carpeta. Devuelve false si no se pudo (solo fiable en Android). */
	public static boolean openFileManager(Path dir) {
		try {
			Files.createDirectories(dir);
		} catch (IOException ignored) {
		}

		if (isAndroid()) {
			return openFileManagerAndroid(dir.toAbsolutePath().toString());
		}

		try {
			Util.getPlatform().openFile(dir.toFile());
			return true;
		} catch (Throwable t) {
			UiTransformMod.LOGGER.warn("No se pudo abrir el administrador de archivos", t);
			return false;
		}
	}

	// ---------------------------------------------------------------- Android

	private static boolean openFileManagerAndroid(String absPath) {
		List<String> attempts = new ArrayList<>();
		String relative = relativeToSharedStorage(absPath);

		if (relative != null) {
			// Abre el gestor de archivos del sistema (DocumentsUI) directamente en esa carpeta.
			String docId = URLEncoder.encode("primary:" + relative, StandardCharsets.UTF_8).replace("+", "%20");
			attempts.add("/system/bin/am start -a android.intent.action.VIEW -t vnd.android.document/directory -d "
					+ shellQuote("content://com.android.externalstorage.documents/document/" + docId));
		}

		attempts.add("/system/bin/am start -a android.intent.action.VIEW -t resource/folder -d "
				+ shellQuote("file://" + absPath.replace(" ", "%20")));
		// Ultimo recurso: abrir el gestor de archivos en la raiz del almacenamiento.
		attempts.add("/system/bin/am start -a android.intent.action.VIEW -t vnd.android.document/root -d "
				+ shellQuote("content://com.android.externalstorage.documents/root/primary"));

		for (String command : attempts) {
			if (runAndroidShell(command)) {
				return true;
			}
		}

		return false;
	}

	private static String relativeToSharedStorage(String absPath) {
		String[] prefixes = {"/storage/emulated/0", "/sdcard", "/storage/self/primary", "/mnt/sdcard"};

		for (String prefix : prefixes) {
			if (absPath.equals(prefix)) {
				return "";
			}

			if (absPath.startsWith(prefix + "/")) {
				return absPath.substring(prefix.length() + 1);
			}
		}

		return null;
	}

	private static String shellQuote(String value) {
		return "'" + value.replace("'", "'\\''") + "'";
	}

	private static boolean runAndroidShell(String command) {
		try {
			// El launcher cambia LD_LIBRARY_PATH; se limpia para que "am" arranque bien.
			ProcessBuilder builder = new ProcessBuilder("/system/bin/sh", "-c", "unset LD_LIBRARY_PATH LD_PRELOAD; " + command);
			builder.redirectErrorStream(true);
			Process process = builder.start();
			String output = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

			if (!process.waitFor(10, TimeUnit.SECONDS)) {
				process.destroyForcibly();
				return false;
			}

			boolean ok = process.exitValue() == 0 && !output.contains("Error") && !output.contains("Exception");

			if (!ok) {
				UiTransformMod.LOGGER.info("Intento de abrir gestor de archivos fallido: {} -> {}", command, output.trim());
			}

			return ok;
		} catch (IOException e) {
			return false;
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return false;
		}
	}

	// ------------------------------------------------------- PC: selector nativo

	private static final String WINDOWS_SCRIPT = String.join(" ",
			"[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;",
			"Add-Type -AssemblyName System.Windows.Forms;",
			"$owner = New-Object System.Windows.Forms.Form;",
			"$owner.TopMost = $true;",
			"$d = New-Object System.Windows.Forms.OpenFileDialog;",
			"$d.Filter = 'Skins PNG (*.png)|*.png';",
			"$d.Title = 'Elige tu skin (PNG 64x64)';",
			"if ($d.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Out.Write($d.FileName) }");

	private static final String MAC_SCRIPT =
			"POSIX path of (choose file with prompt \"Elige tu skin (PNG 64x64)\" of type {\"public.png\"})";

	/** Abre el selector de archivos NATIVO del sistema para elegir un PNG. Bloquea hasta que el usuario elige. */
	public static PickResult pickPng() {
		if (isAndroid()) {
			return PickResult.UNAVAILABLE;
		}

		if (isWindows()) {
			return runPicker(List.of("powershell.exe", "-NoProfile", "-STA", "-WindowStyle", "Hidden", "-Command", WINDOWS_SCRIPT));
		}

		if (isMac()) {
			return runPicker(List.of("osascript", "-e", MAC_SCRIPT));
		}

		PickResult zenity = runPicker(List.of("zenity", "--file-selection", "--title=Elige tu skin (PNG)", "--file-filter=PNG | *.png"));

		if (!zenity.unavailable()) {
			return zenity;
		}

		return runPicker(List.of("kdialog", "--getopenfilename", System.getProperty("user.home", "."), "*.png"));
	}

	private static PickResult runPicker(List<String> command) {
		try {
			Process process = new ProcessBuilder(command)
					.redirectError(ProcessBuilder.Redirect.DISCARD)
					.start();
			String output = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8)
					.replace("﻿", "")
					.trim();
			int exit = process.waitFor();

			if (exit == 0 && !output.isEmpty()) {
				Path path = Path.of(output.lines().findFirst().orElse(output).trim());

				if (Files.isRegularFile(path)) {
					return new PickResult(path, false);
				}
			}

			return PickResult.CANCELLED;
		} catch (IOException e) {
			return PickResult.UNAVAILABLE;
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return PickResult.CANCELLED;
		} catch (RuntimeException e) {
			return PickResult.CANCELLED;
		}
	}
}
